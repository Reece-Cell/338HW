package com.example.csumbflashcard;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.csumbflashcard.databinding.ActivityMainBinding;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button showButton;
    private Button markButton;
    private Button randButton;
    private Button resetButton;
    int QuestionNum;
    int remainingcards;;
    int[] Mark = {8, 8, 8, 8, 8, 8, 8, 8};
    int pos = 0;

    private ActivityMainBinding binding;
    private List<Question> questionList = Arrays.asList(
            new Question(R.string.question_compiler, R.string.answer_express),
            new Question(R.string.question_os, R.string.answer_os),
            new Question(R.string.question_rdbmbs, R.string.answer_rdbms),
            new Question(R.string.question_https, R.string.answer_https),
            new Question(R.string.question_internet, R.string.answer_internet),
            new Question(R.string.question_express, R.string.answer_express),
            new Question(R.string.question_conduct, R.string.answer_conduct),
            new Question(R.string.question_toast, R.string.answer_toast)
    );

    private Question currentQuestion = questionList.get(QuestionNum);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        View view = binding.getRoot();

        QuestionNum = 0;
        remainingcards = 7;
        binding.questionTextView.setText(currentQuestion.getTextResId());

        showButton = binding.showAnswerButton;
        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Toast.makeText(MainActivity.this, currentQuestion.getTextResAnsw(), Toast.LENGTH_SHORT).show();
            }
        });

        binding.resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentQuestion = questionList.get(0);
                QuestionNum = 0;
                remainingcards = 7;
                pos = 0;
                for(int i = 0; i < 8; i++){
                    Mark[i] = 8;
                }
                Toast.makeText(MainActivity.this, "Cards Reset!", Toast.LENGTH_LONG).show();
            }
        });

        binding.markButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Mark[pos] = QuestionNum;
                pos++;
                Toast.makeText(MainActivity.this, "Card Marked!", Toast.LENGTH_LONG).show();
                remainingcards--;
            }
        });
        binding.randomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(pos == 7){
                    binding.questionTextView.setText("No More Cards!");
                }else{
                    Random rand = new Random();
                    QuestionNum = rand.nextInt(7);
                    while (markCorrect(QuestionNum) == true){
                        QuestionNum = rand.nextInt(7);
                    }

                }
                currentQuestion = questionList.get(QuestionNum);
                binding.questionTextView.setText(currentQuestion.getTextResId());
            }
        });
    }

    public void changeCase(View v){
        if(v.getId() == R.id.random_button){
            Toast t = Toast.makeText(getApplicationContext(), currentQuestion.getTextResId(),
                    Toast.LENGTH_SHORT);
           t.show();
        }else if (v.getId() == R.id.mark_button){
           Toast t = Toast.makeText(getApplicationContext(), "Question Complete!",
                    Toast.LENGTH_SHORT);
           t.show();
        }
    }

    boolean markCorrect(int currentnum){
        for(int i = 0; i < 8; i++){
            if (currentnum == Mark[i]){
                return true;
            }
        }
        return false;
    }
}