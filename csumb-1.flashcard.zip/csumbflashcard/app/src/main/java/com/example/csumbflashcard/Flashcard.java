package com.example.csumbflashcard;

public class Flashcard {
    private int questionId;
    private int answerId;
    private boolean complete;

    public Flashcard(int questionId, int answerId) {
        this.questionId = questionId;
        this.answerId = answerId;
        this.complete = false;
    }

    public int getQuestionId() {
        return questionId;
    }

    public int getAnswerId() {
        return answerId;
    }

    public boolean isComplete() {
        return complete;
    }

    public void setComplete(boolean complete) {
        this.complete = complete;
    }
}
