package com.example.csumbflashcard;

public class Question {

    private int textResId;
    private int textResAnsw;

    public int getTextResId() {
        return textResId;
    }

    public void setTextResId(int textResId) {
        this.textResId = textResId;
    }

    public int getTextResAnsw() {
        return textResAnsw;
    }

    public void setTextResAnsw(int textResAnsw) {
        this.textResAnsw = textResAnsw;
    }

    public Question(int textResId, int textResAnsw) {
        this.textResId = textResId;
        this.textResAnsw = textResAnsw;
    }
}
